source ${0:A:h}/vi-mode.zsh
