#!/bin/bash
conky -c $HOME/.config/conky/conky.conf &
conky -c $HOME/.config/conky/conky_notes.conf &
